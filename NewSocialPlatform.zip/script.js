function startApp() {
  document.querySelector('.welcome-screen').classList.add('hidden');
  document.querySelector('#app').classList.remove('hidden');
}